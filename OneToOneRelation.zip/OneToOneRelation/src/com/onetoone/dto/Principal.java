package com.onetoone.dto;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class Principal {
	@Id
	@GenericGenerator(name="Principal_seq",strategy="increment")
	@GeneratedValue(generator="Principal_seq")
	@Column(name="Principal_Id")
	private int id; 
	@Column(name="Principal_Name")
	private String principalName;
	@Column(name="Principal_Experience")
	private int principalExperience;
	@Column(name="Principal_Age")
	private int principalAge;
	@Column(name="Principal_Salary")
	private int principalSalary;
	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="Principal_College_Id")
	private College principalToCollege;
	public Principal() {
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPrincipalName() {
		return principalName;
	}
	public void setPrincipalName(String principalName) {
		this.principalName = principalName;
	}
	public int getPrincipalExperience() {
		return principalExperience;
	}
	public void setPrincipalExperience(int principalExperience) {
		this.principalExperience = principalExperience;
	}
	public int getPrincipalAge() {
		return principalAge;
	}
	public void setPrincipalAge(int principalAge) {
		this.principalAge = principalAge;
	}
	public int getPrincipalSalary() {
		return principalSalary;
	}
	public void setPrincipalSalary(int i) {
		this.principalSalary = i;
	}
	public College getPrincipalToCollege() {
		return principalToCollege;
	}
	public void setPrincipalToCollege(College principalToCollege) {
		this.principalToCollege = principalToCollege;
	}
}
