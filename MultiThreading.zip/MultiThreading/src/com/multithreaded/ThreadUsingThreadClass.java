package com.multithreaded;

public class ThreadUsingThreadClass extends Thread{
	public ThreadUsingThreadClass() {
		// TODO Auto-generated constructor stub
	}
	public ThreadUsingThreadClass(String s) {
		// TODO Auto-generated constructor stub
		super.setName(s);
	}
		public synchronized void run()
		{
			for(int i=0;i<10;++i)
			System.out.println("Thread is running and count is : " + i + " Thread Name : " + Thread.currentThread().getName());
			/*if(Thread.currentThread().getName().equalsIgnoreCase("Thread A"))
					{
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}*/
		}
}
