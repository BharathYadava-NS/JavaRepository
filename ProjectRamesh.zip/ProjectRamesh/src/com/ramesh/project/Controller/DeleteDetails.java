package com.ramesh.project.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ramesh.project.DAO.DBOperations;

/**
 * Servlet implementation class DeleteDetails
 */
//@WebServlet("/DeleteDetails")
public class DeleteDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		//out.println(request.getParameter("pk"));
		DBOperations d=new DBOperations();
		try {
			if(d.deleteData(request.getParameter("pk")))
			{
				out.println("Data Deleted Successfully");
				String s="<br><br><hr><br><br><form action='/ProjectRamesh/EmployeeLedger.jsp'><input type='submit' value='Employee Ledger' style='width:200px'></form>";
				out.println(s);
			}
			else
			{
				out.println("Problem in Deleting data please contact support team.");
			}
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Exception Occured");
		}
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(req, resp);
	}

}
