package com.SqlDB;

import java.sql.SQLException;

public class Tester {

	public static void main(String[] args) throws SQLException{
		// TODO Auto-generated method stub
		/*
		 * Returns a Connection Instance Refernce
		 */
			//	Connection c=DBConnection.creatConnection();
			//  System.out.println("Connection Created");
			//	DBConnection.closeConnetion(c);
			//	System.out.println("Connection Terminated");
		/*
		 * Terminates the Connection
		 */
		
		/*
		 * SimpleFetch operation in a class named SimpleFetch
		 * 
		 */
		SimpleFetch f=new SimpleFetch();
		f.deleteUserById(1);
		f.doFetchAll();
		f.insertEntry(1,"Harish","MV","MVH@gmail.com",9739797547l,23);
		f.doFetchAll();
		f.getMataDataInfo();
	}

}
