package com.onetomany.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name="Student_Table")
public class Student {
	@Id
	@GenericGenerator(name="Student_seq",strategy="increment")
	@GeneratedValue(generator="Student_seq")
	@Column(name="Student_id")
	private int id;
	@Column(name="student_name")
	private String studentName;
	@Column(name="student_age")
	private int studentAge;
	@Column(name="student_number")
	private long studentNumber;
	@Column(name="student_emil")
	private String studentEmail;
	@ManyToOne
	@JoinColumn(name="Student_Section_id")
	private Section studentSection;
	public Student() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public int getStudentAge() {
		return studentAge;
	}

	public void setStudentAge(int studentAge) {
		this.studentAge = studentAge;
	}

	public long getStudentNumber() {
		return studentNumber;
	}

	public void setStudentNumber(long studentNumber) {
		this.studentNumber = studentNumber;
	}

	public String getStudentEmail() {
		return studentEmail;
	}

	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}

	public Section getStudentSection() {
		return studentSection;
	}

	public void setStudentSection(Section studentSection) {
		this.studentSection = studentSection;
	}
	
}
