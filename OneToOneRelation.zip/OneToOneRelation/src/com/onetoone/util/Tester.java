package com.onetoone.util;

import com.onetoone.dao.CollegePrincipal;
import com.onetoone.dto.College;
import com.onetoone.dto.Principal;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		College c1=new College();
		Principal p1=new Principal();
		String[] s1={"ECE","EEE","CSE"};
		for (String string : s1) {
			System.out.println(string);
		}
		c1.setCollegeDepartments(s1);
		c1.setCollegeFacultyCount(20);
		c1.setCollegeName("UBDT");
		c1.setCollegeStrength(2000);
		c1.setCollegePrincipal(p1);
		p1.setPrincipalAge(50);
		p1.setPrincipalExperience(25);
		p1.setPrincipalName("UBDT Principal");
		p1.setPrincipalSalary(25000);
		p1.setPrincipalToCollege(c1);
		
		CollegePrincipal dao=new CollegePrincipal();
		
		dao.saveCollegePrincipalDetails(c1);
		
		System.out.println("Saved Successfully");
		
		dao.getCollegePrincipalDetails();
		
		System.out.println("Details Displayed Successfully");
	}

}
