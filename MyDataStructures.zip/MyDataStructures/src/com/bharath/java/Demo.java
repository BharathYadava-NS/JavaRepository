package com.bharath.java;

//import java.io.IOException;
import java.lang.reflect.*;

//import java.io.PrintStream;

public class Demo {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
			ClassId c=new ClassId();
			ClassId c1=new ClassId();
			System.out.println(c.toString());
			System.out.println(c.hashCode());
			System.out.println(c.getClass());
			System.out.println(Integer.toHexString(c.hashCode()));
			System.out.println(c1.toString());
			System.out.println(c1.hashCode());
			System.out.println(c1.getClass());
			/*try {
				System.out.println(System.in.read());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			Class<? extends Object> d=c.getClass();
			System.out.println(d.getName());
			Method[] m=d.getMethods();
			for(Method M:m)
			{
				System.out.println(M);
			}
			Field[] f=d.getDeclaredFields();
			for(Field F:f)
			{
				System.out.println(F);
			}
	}
}
