package com.onetomany.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hibernate.HibernateDBConfiguration;
import com.onetomany.dto.Section;
import com.onetomany.dto.Student;

public class StudentsInSection {

	public void saveDetailsOfStudents(Section s1) {
		// TODO Auto-generated method stub
		Session s=HibernateDBConfiguration.getSessionFactoryObject().openSession();
		Transaction t=s.beginTransaction();
		try {
			s.save(s1);
			t.commit();
		} catch (Exception e) {
			// TODO: handle exception
			t.rollback();
			System.out.println("Exception Occured");
		}
		finally {
			s.close();
		}
		
	}

	public void getDetailsOfStudents() {
		// TODO Auto-generated method stub
		Session ss=HibernateDBConfiguration.getSessionFactoryObject().openSession();
		Transaction t=ss.beginTransaction();
		Query q=ss.createQuery("Select s from Section s");
		try
		{
		List<Section> l=new ArrayList<>(q.list());
		Iterator<Section> i=l.iterator();
		while (i.hasNext()) {
			Section s = (Section) i.next();
			System.out.println(""+s.getSectionName()+s.getSectionTeacher()+s.getSectionCapacity());
			List<Student> sl=s.getStudentList();
			Iterator<Student> is=sl.iterator();
			while (is.hasNext()) {
				Student st = (Student) is.next();
				System.out.println(""+st.getStudentName()+st.getStudentAge()+st.getStudentEmail()+st.getStudentNumber());
			}
		}
		}
		catch(Exception e)
		{
			System.out.println("Exception");
		}
		finally {
			ss.close();
		}
	}

}
