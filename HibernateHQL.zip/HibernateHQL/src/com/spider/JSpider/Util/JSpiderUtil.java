package com.spider.JSpider.Util;

import com.spider.JSpider.Dao.JSpiderDao;
import com.spider.JSpider.Dto.JSpiderDto;

public class JSpiderUtil {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			JSpiderDao dao=new JSpiderDao();
			JSpiderDto dto=new JSpiderDto();
			dto.setBranch("RajajiNagar");
			dto.setCourse("Java");
			dto.setFaculty("Keshav");
			dto.setFees(9000);
			dto.setStudentCount(100);
			System.out.println(Integer.toHexString(dto.hashCode()));
			dao.addData(dto);
			dto.setBranch("RajajiNagar");
			dto.setCourse("SQL");
			dto.setFaculty("Sachin");
			dto.setFees(5400);
			dto.setStudentCount(100);
			System.out.println(Integer.toHexString(dto.hashCode()));
			dao.addData(dto);
			dto.setBranch("RajajiNagar");
			dto.setCourse("FrameWorks");
			dto.setFaculty("Prateek");
			dto.setFees(5400);
			dto.setStudentCount(100);
			System.out.println(Integer.toHexString(dto.hashCode()));
			dao.addData(dto);
			dao.getData();
			String s=dao.getFacultyByCourse("Java");
			System.out.println("Java Class is taken by " + s);
			s=dao.getFacultyByCourse("FrameWorks");
			System.out.println("FrameWork Class is taken by " + s);
			s = dao.getCourseByFaculty("Keshav");
			System.out.println(s + " Class is taken by Keshav");
			s = dao.getCourseByFaculty("Prateek");
			System.out.println(s + " Class is taken by Prateek");
			//dao.deleteValueByName("Keshav");
			//System.out.println("Entry is Deleted Successfully");
			int count=dao.getEntityCount();
			System.out.println("Entity Count is " + count);
			int fee=dao.getFeeByCourse("Java");
			System.out.println("Fee for java course is : " + fee);
			fee=dao.getFeeByCourse("FrameWorks");
			System.out.println("Fee for FrameWorks course is : " + fee);
	}

}
