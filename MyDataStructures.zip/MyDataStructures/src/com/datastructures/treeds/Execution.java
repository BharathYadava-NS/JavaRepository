package com.datastructures.treeds;

public class Execution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			BinaryTree b=new BinaryTree();
			/*	b.add(50);
			b.add(75);
			b.add(25);
			b.add(60);
			b.add(65);
			b.add(20);
			b.add(15);	*/
			/*	b.add(1);
			b.add(2);
				b.add(3);
			b.add(4);
				b.add(5);
			b.add(6);	*/
			b.display(); 
			//b.delete(25);
			//b.sort();
	}
}
