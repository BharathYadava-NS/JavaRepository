package com.bharath.java;

public class BinToDec {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			BinToDec b=new BinToDec();
			System.out.println(" Bin : 11 - Decimal Value : "+ b.convert(11));
			System.out.println(" Bin : 1101 - Decimal Value : " + b.convert(1101));
			System.out.println(" Bin : 11001 - Decimal Value : " + b.convert(11001));
			System.out.println(" Bin : 110 - Decimal Value : " + b.convert(110));
			System.out.println(" Bin : 100110 - Decimal Value : " + b.convert(100110));
	}

	private int convert(int i) {
		// TODO Auto-generated method stub
		int num=0;
		int power=String.valueOf(i).length();
		for(int j=0;j<power;++j)
		{
			if(i%10==1)
			num+=Math.pow(2, j);
			i=i/10;
		}
		return num;
	}

}
