package com.datastructures.stack;

import java.util.ArrayList;
import java.util.ListIterator;

public class Stack <T>{
		private int size;
		ArrayList<T> a= new ArrayList<>();
		public Stack() {
			//super();
			this.size=10;
			a.ensureCapacity(size);
			System.out.println("Stack Created With size : " + size);
			//ArrayList<T> a= new ArrayList<>(size);
		}
		public Stack(int size) {
			//super();
			this.size=size;
			a.ensureCapacity(size);
			System.out.println("Stack Created With size : " + size);
			//ArrayList<T> a= new ArrayList<>(size);
		}
		//private T data;
		
		public void peek() {
			// TODO Auto-generated method stub
			System.out.println("Peek Opertion");
			try
			{
			System.out.println("Peek / Top Element : " + a.get(a.size()-1));
			}
			catch(Exception e)
			{
				System.out.println("Stack is Empty");
			}
		}
		public void pop() {
			// TODO Auto-generated method stub
			System.out.println("Pop Operation");
			System.out.println("Removed Element : " + a.remove(a.size()-1));
		}
		public void push(T data) {
			System.out.println("Push Operation");
			// TODO Auto-generated method stub
			if(a.size()>size)
			{
				System.out.println("Stack OverFlow");		
			}
			else
			{
			a.add(data);
			System.out.println("Push Successful");
			}
		}
		public void Display()
		{
			ListIterator<T> l=a.listIterator();
			//System.out.println("Entered Display");
			while(l.hasNext())
			{
				l.next();
			}
			while(l.hasPrevious())
			{
				System.out.println(l.previous());
			}
			//System.out.println("Exit Display");
		}
}
