package com.bharath.java;

public class Pattern2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			int mx=5,sum=0;
			for(int i=1;i<=mx;++i)
			{
				sum=0;
				for(int j=1;j<=mx;++j)
				{
					if(j<=i)
					{
					System.out.print(j);
					sum+=j;
					}
					else
					{
					System.out.print(" ");
					}
				}
				System.out.println("   " + sum);
			}
	}

}
