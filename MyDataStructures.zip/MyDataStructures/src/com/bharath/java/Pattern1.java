package com.bharath.java;

public class Pattern1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			char[] ch={'a','b','c','d'};
			for(int i=ch.length-1;i>=0;--i)
			{
				int temp=0;
				for(int j=0;j<=i;++j)
				{
					System.out.print(ch[j]);
					temp++;
				}
				temp*=2;
				while(temp<(ch.length*2))
				{
					System.out.print(" ");
					temp++;
				}
				//System.out.println();
				for(int k=i;k>=0;--k)
				{
					System.out.print(ch[k]);
				}
				System.out.println();
			}
			for(int i=0;i<=ch.length-1;++i)
			{
				int temp=0;
				for(int k=0;k<=i;++k)
				{
					System.out.print(ch[k]);
					temp++;
				}
				
				temp*=2;
				while(temp<(ch.length*2))
				{
					System.out.print(" ");
					temp++;
				}
				//System.out.println();
				for(int j=i;j>=0;--j)
				{
					System.out.print(ch[j]);
					
				}
				System.out.println();
			}
	}

}
