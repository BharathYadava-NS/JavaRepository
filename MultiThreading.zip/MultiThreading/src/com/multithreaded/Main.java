package com.multithreaded;

import java.io.IOException;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			ThreadUsingThreadClass t1=new ThreadUsingThreadClass("Thread A");
			ThreadUsingThreadClass t2=new ThreadUsingThreadClass("Thread B");
			ThreadUsingRunnableInterface r1=new ThreadUsingRunnableInterface();
			ThreadUsingRunnableInterface r2=new ThreadUsingRunnableInterface();
			Thread t3=new Thread(r1, "Thread C");
			Thread t4=new Thread(r2, "Thread D");
			//t1.setPriority(10);
			t1.start();
			//t2.setPriority(5);
			/*try {
				t1.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			t2.start();
			t3.start();
			/*try {
				t3.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			t4.start();
			System.out.println(t1.getId());
			System.out.println(t2.getId());
			System.out.println(t3.getId());
			System.out.println(t4.getId());
			/*if(t1.isDaemon())
			{
				System.out.println("This is a Daemon Thread");
			}
			else
			{
				System.out.println("This is not a Daemon Thread");
			}
			t1.setDaemon(true);
			 
			Runtime r=Runtime.getRuntime();
			try {
				r.exec("");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			//Concept of DeadLock
			String s1="String 1";
			String s2="String 2";
			Thread t5=new Thread(){
				@Override
				public void run() {
					// TODO Auto-generated method stub
					synchronized (s1) {
						try { Thread.sleep(1000);} catch (Exception e) {} 
						synchronized (s2) {
							System.out.println("Acquired Lock on S1 first and seond on s2");
						}
					}
				}
			};
			Thread t6=new Thread(){
				@Override
				public void run() {
					// TODO Auto-generated method stub
					synchronized (s2) {
						try { Thread.sleep(1000);} catch (Exception e) {}  
						synchronized (s1) {
							System.out.println("Acquired Lock on S2 first and seond on s1");
						}
					}
				}
			};
			t5.start();
			t6.start();
			System.out.println("DeadLock");
	}

}
