package com.onetomany.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name="Section_Table")
public class Section {
	@Id
	@GenericGenerator(name="Section_seq",strategy="increment")
	@GeneratedValue(generator="Section_seq")
	@Column(name="section_id")
	private int id;
	@Column(name="section_name")
	private String sectionName;
	@Column(name="section_capacity")
	private int sectionCapacity;
	@Column(name="section_teacher")
	private String sectionTeacher;
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY,mappedBy="studentSection",targetEntity=Student.class)
	@PrimaryKeyJoinColumn
	private List<Student> studentList;
	public Section() {
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSectionName() {
		return sectionName;
	}
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}
	public int getSectionCapacity() {
		return sectionCapacity;
	}
	public void setSectionCapacity(int sectionCapacity) {
		this.sectionCapacity = sectionCapacity;
	}
	public String getSectionTeacher() {
		return sectionTeacher;
	}
	public void setSectionTeacher(String sectionTeacher) {
		this.sectionTeacher = sectionTeacher;
	}
	public List<Student> getStudentList() {
		return studentList;
	}
	public void setStudentList(List<Student> studentList) {
		this.studentList = studentList;
	}
	
}
