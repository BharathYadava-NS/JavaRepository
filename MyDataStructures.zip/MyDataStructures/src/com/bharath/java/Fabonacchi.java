package com.bharath.java;

public class Fabonacchi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Fabonacchi f=new Fabonacchi();
			f.generate(15);
	}

	private void generate(int n) {
		// TODO Auto-generated method stub
		int[] arr=new int[n];
		arr[0]=0;arr[1]=1;
		for(int i=0;i<n;++i)
		{
			if(i>1)
				arr[i]=arr[i-1]+arr[i-2];
				System.out.println(arr[i]);
		}
	}

}
