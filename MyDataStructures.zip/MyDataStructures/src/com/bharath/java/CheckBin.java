package com.bharath.java;

public class CheckBin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CheckBin c=new CheckBin();
		System.out.println("Binary Number : 11010011 : " + c.checkNum(11010011));
		System.out.println("Binary Number : 11013011 : " + c.checkNum(11013011));
		System.out.println("Binary Number : 110345011 : " + c.checkNum(110345011));
		System.out.println("Binary Number : 0000000 : " + c.checkNum(0000000));
	}

	private boolean checkNum(int n) {
		// TODO Auto-generated method stub
		while(n>0)
		{
			if(n%10!=0 && n%10!=1)
				return false;
			n=n/10;
		}
		return true;
	}

}
