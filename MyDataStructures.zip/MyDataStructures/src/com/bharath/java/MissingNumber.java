package com.bharath.java;

import java.util.ArrayList;

public class MissingNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> i=new ArrayList<>();
		for(int j=0;j<20;++j)
		{
			i.add(j+1);
		}
		i.set(12, 0);//Missing Number
		int sum=0,s=i.size();
		for (Integer integer : i) {
			System.out.print(integer + " ");
			sum+=integer;
		}
		s=(s*(s+1)/2)-sum;
		System.out.println("Missing number is : " + s);
	}
}
