package com.datastructures.treeds;

public class Node {
	private int data;
	private Node lnode;
	public Node()
	{
		
	}
	public Node(int data) {
		this.data = data;
	}
	public int getData() {
		return data;
	}
	public void setData(int data) {
		this.data = data;
	}
	public Node getLnode() {
		return lnode;
	}
	public void setLnode(Node lnode) {
		this.lnode = lnode;
	}
	public Node getRnode() {
		return rnode;
	}
	public void setRnode(Node rnode) {
		this.rnode = rnode;
	}
	private Node rnode;
}
