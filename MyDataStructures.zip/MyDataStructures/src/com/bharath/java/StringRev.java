package com.bharath.java;

public class StringRev {

		public String rev(String s)
		{
			String t="";
			if((s.length()-1)<0)
			{
				return "";
			}
			else
			{
				t+=s.charAt(s.length()-1)+rev(s.substring(0,(s.length()-1)));
			}
			return t;
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			StringRev r=new StringRev();
			System.out.print(r.rev("BharathYadavaNS"));
	}
}
