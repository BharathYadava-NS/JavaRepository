package com.bharath.java;

public class SumOfDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			SumOfDigits s=new SumOfDigits();
			s.findSum(6534);
	}

	private void findSum(int i) {
		int sum=0;// TODO Auto-generated method stub
		while(i>0)
		{
			sum+=i%10;
			i/=10;
		}
		System.out.println(sum);
	}

}
