package com.bharath.java;

public class ArrayTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			int[] a1=new int[5];
			a1[1]=2;
			System.out.println(a1[1]);
			int[][] a2=new int[2][5];
			a2[0][1]=1;
			System.out.println(a2[0][1]);
			System.out.println((int)(Math.random()*1000000));
	}

}
