package com.spider.JSpider.Dao;

import com.spider.JSpider.Dto.JSpiderDto;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.hibernate.HibernateDBConfiguration;

public class JSpiderDao {

	public void addData(JSpiderDto dto) {
		// TODO Auto-generated method stub
		SessionFactory sf = HibernateDBConfiguration.getSessionFactoryObject();
		Session s = sf.openSession();
		Transaction tx = s.beginTransaction();
		s.save(dto);
		tx.commit();
		s.close();
		sf.close();
	}
	// JSpiderDto d=new JSpiderDto();

	public void getData() {
		// TODO Auto-generated method stub
		SessionFactory sf = HibernateDBConfiguration.getSessionFactoryObject();
		Session s = sf.openSession();
		// Transaction tx=s.beginTransaction();
		String qryHql = "Select j from JSpiderDto j";
		Query q = s.createQuery(qryHql);
		List<JSpiderDto> l = new ArrayList<>(q.list());
		Iterator i = l.iterator();
		while (i.hasNext()) {
			JSpiderDto d = (JSpiderDto) i.next();
			System.out.println("======" + d.getBactchId() + "===" + d.getBranch() + "=======" + d.getCourse() + "======"
					+ d.getFaculty() + "==========" + d.getFees() + "=========" + d.getStudentCount());
			System.out.println(
					"-------------------------------------------------------------------------------------------------------------------------------");
		}
		s.close();
		sf.close();
	}

	public String getFacultyByCourse(String string) {
		// TODO Auto-generated method stub
		SessionFactory sf = HibernateDBConfiguration.getSessionFactoryObject();
		Session s = sf.openSession();
		// Transaction tx=s.beginTransaction();
		String qryHql = "Select j.faculty from JSpiderDto j where course='" + string + "'";
		Query q = s.createQuery(qryHql);
		String st = (String) q.uniqueResult();
		s.close();
		sf.close();
		return st;
	}

	public String getCourseByFaculty(String string) {
		// TODO Auto-generated method stub
		SessionFactory sf = HibernateDBConfiguration.getSessionFactoryObject();
		Session s = sf.openSession();
		// Transaction tx=s.beginTransaction();
		String qryHql = "Select j.course from JSpiderDto j where faculty='" + string + "'";
		Query q = s.createQuery(qryHql);
		String st = (String) q.uniqueResult();
		s.close();
		sf.close();
		return st;
	}

	public void deleteEntryByFaculty(String string) {
		// TODO Auto-generated method stub
		SessionFactory sf = HibernateDBConfiguration.getSessionFactoryObject();
		Session s = sf.openSession();
		Transaction tx = s.beginTransaction();
		String qryHql = "delete from JSpiderDto j where faculty='" + string + "'";
		Query q = s.createQuery(qryHql);
		q.executeUpdate();
		tx.commit();
		s.close();
		sf.close();
	}

	public int getEntityCount() {
		// TODO Auto-generated method stub
		SessionFactory sf = HibernateDBConfiguration.getSessionFactoryObject();
		Session s = sf.openSession();
		// Transaction tx=s.beginTransaction();
		String qryHql = "Select j from JSpiderDto j";
		Query q = s.createQuery(qryHql);
		// List<JSpiderDto> l=new ArrayList<>(q.list());
		int count = q.list().size();
		s.close();
		sf.close();
		return count;
	}

	public int getFeeByCourse(String string) {
		// TODO Auto-generated method stub
		SessionFactory sf = HibernateDBConfiguration.getSessionFactoryObject();
		Session s = sf.openSession();
		// Transaction tx=s.beginTransaction();
		String qryHql = "Select j.fees from JSpiderDto j where course='" + string + "'";
		Query q = s.createQuery(qryHql);
		int st = (int) q.uniqueResult();
		s.close();
		sf.close();
		return st;
	}
}
