package com.bharath.java;

public class BinarySearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a={9,8,7,6,5,4,3,2,1};
		BinarySearch s=new BinarySearch();
		int num=1;
		s.bubbleSort(a);
		System.out.println("result :" + s.search(a,num));
	}

	private boolean search(int[] a,int num) {
		// TODO Auto-generated method stub
		int l=0,h=a.length-1,mid=0;
		while(l<=h)
		{
			mid=(l+h)/2;
			if(a[mid]==num)
			{
				System.out.println("Number Found");
				return true;
			}
			else if(a[mid]<num)
			{
				l=mid+1;
			}
			else
			{
				h=mid-1;
			}
		}
		System.out.println("Number not found");
		return false;
	}
	void bubbleSort(int[] a) {
		// TODO Auto-generated method stub
		this.print(a);
		System.out.println();
		for(int i=0;i<a.length-1;++i)
		{
			for(int j=0;j<a.length-1;++j)
			{
				if(a[j]>a[j+1])
				{
					a[j]+=a[j+1]-(a[j+1]=a[j]);
				}
			}
			this.print(a);
			System.out.println();
		}
	}

	private void print(int[] a) {
		// TODO Auto-generated method stub
		for(int i=0;i<a.length;++i)
		{
			System.out.print(a[i] + " ");
		}
	}

	

}
