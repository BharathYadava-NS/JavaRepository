package com.onetoone.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hibernate.HibernateDBConfiguration;
import com.onetoone.dto.College;

public class CollegePrincipal {

	public void saveCollegePrincipalDetails(College c1) {
		// TODO Auto-generated method stub
		Session s=HibernateDBConfiguration.getSessionFactoryObject().openSession();
		Transaction t=s.beginTransaction();
		try
		{
		s.save(c1);
		t.commit();
		}
		catch(Exception e)
		{
			t.rollback();
		}
		finally {
			s.close();
		}
	}

	public void getCollegePrincipalDetails() {
		// TODO Auto-generated method stub
		Session s=HibernateDBConfiguration.getSessionFactoryObject().openSession();
		Transaction t=s.beginTransaction();
		try
		{
		Query q=s.createQuery("Select c from College c");
		List<College> l=new ArrayList<>(q.list());
		Iterator i=l.iterator();
		while (i.hasNext()) {
			College c = (College) i.next();
			System.out.println("College Id : " + c.getCollegeId() +"\nCollege Name : "+ c.getCollegeName()+ "\nCollege Strength : " +c.getCollegeStrength() +"\nPrincipal Name : "+ c.getCollegePrincipal().getPrincipalName());
		}
	}
	catch(Exception e)
	{
		System.out.println("Exception Occured");
	}
	finally {
		s.close();
	}
	}
	
}
