package com.ramesh.project.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.ramesh.project.DTO.EmplyeeDetailsClass;

public class DBOperations {
	private Connection c=null;
	private String query=null;
	private ResultSet rs=null;
	public DBOperations() {
		// TODO Auto-generated constructor stub
		try {
			c=DBClass.createConnection();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("SQL Exception");
		}
	}
	public boolean saveData(EmplyeeDetailsClass e) throws SQLException {
		// TODO Auto-generated method stub
		//System.out.println("SQL Operation is Performing");
		PreparedStatement p=c.prepareStatement("insert into EmployeeTable() values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		p.setInt(1, e.getEmployeeId());
		p.setString(2, e.getEmployeeName());
		p.setString(3, e.getContactNumber());
		p.setString(4, e.getEmergencyContactPerson());
		p.setString(5, e.getContactPersonNumber());
		p.setString(6, e.getEmailId());
		p.setString(7, e.getGender());
		p.setString(8, e.getQualification());
		p.setString(9, e.getDesignation());
		p.setNString(10, e.getDateOfJoining());
		p.setString(11, e.getStatus());
		p.setString(12, e.getDepartment());
		p.setString(13, e.getDateOfBirth());
		p.setString(14, e.getAddress());
		p.setString(15, e.getOtherDetails());
		boolean value=p.executeUpdate()>0?true:false;
		if(value)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public ResultSet getAllEmployeeDetails() throws SQLException
	{
		Statement s=c.createStatement();
		query="Select * From EmployeeTable";
		rs=s.executeQuery(query);
		//System.out.println(rs.getInt(1));
		//System.out.println("Exit Query");
		return rs;
	}
	public ResultSet editDetails(int pk) throws SQLException {
		// TODO Auto-generated method stub
		System.out.println("Query Execution Entry");
		Statement s=c.createStatement();
		query="Select * from EmployeeTable where EmployeeId='"+pk+"'";
		rs=s.executeQuery(query);
		System.out.println("Execution Completed");
		return rs;
	}
	public boolean updateData(EmplyeeDetailsClass e) throws SQLException {
		// TODO Auto-generated method stub
		PreparedStatement p=c.prepareStatement("UPDATE EmployeeTable SET EmployeeName=?,ContactNumber=?,EmergencyContactPerson=?,EmegencyContactNumber=?,EmailId=?,Gender=?,Qualification=?,Designation=?,DateOfJoining=?,Status=?,Department=?,DateOfBirth=?,Address=?,OtherDetails=? WHERE EmployeeId="+e.getEmployeeId()+";");
		//p.setInt(1, e.getEmployeeId());
		p.setString(1, e.getEmployeeName());
		p.setString(2, e.getContactNumber());
		p.setString(3, e.getEmergencyContactPerson());
		p.setString(4, e.getContactPersonNumber());
		p.setString(5, e.getEmailId());
		p.setString(6, e.getGender());
		p.setString(7, e.getQualification());
		p.setString(8, e.getDesignation());
		p.setString(9, e.getDateOfJoining());
		p.setString(10, e.getStatus());
		p.setString(11, e.getDepartment());
		p.setString(12, e.getDateOfBirth());
		p.setString(13, e.getAddress());
		p.setString(14, e.getOtherDetails());
		boolean value=p.executeUpdate()>0?true:false;
		if(value)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public boolean deleteData(String pk) throws SQLException {
		// TODO Auto-generated method stub
		Statement s=c.createStatement();
		query="DELETE FROM EmployeeTable WHERE EmployeeId IN ("+pk+")";
		int r=s.executeUpdate(query);
		//System.out.println(rs.getInt(1));
		System.out.println("Exit Query");
		if(r>0)
		return true;
		else
		return false;
	}
}
