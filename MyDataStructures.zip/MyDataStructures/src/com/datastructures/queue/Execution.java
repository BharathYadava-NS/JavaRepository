package com.datastructures.queue;

import java.util.Scanner;

public class Execution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			start();
	}
	public static void start() {
		// TODO Auto-generated method stub
		boolean operation=true;
		Scanner i=new Scanner(System.in);
		Queue<Integer> s=new Queue<>(20);
		while(operation)
		{
			System.out.println("Enter the Operation To Perform : \n 1.Push\n 2.Pop\n 3.Peek\n 4.Display\n 5.exit");
			int t=i.nextInt();
			switch(t)
			{
			case 1:
				System.out.println("Enter the Element to be pushed : ");
				s.push(i.nextInt());
				break;
			case 2:
				s.pop();
				break;
			case 3:
				s.peek();
				break;
			case 4:
				s.Display();
				break;
			case 5:
				operation=false;
				i.close();
				System.out.println("Program Terminated");
				break;
			default:	
				System.out.println(" Please Enter a choice from given operations ");
				break;
			}
		}
	}
}
