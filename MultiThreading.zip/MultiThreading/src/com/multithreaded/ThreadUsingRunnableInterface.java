package com.multithreaded;

public class ThreadUsingRunnableInterface implements Runnable{

		// TODO Auto-generated method stub
			public synchronized void run()
			{
				for(int i=0;i<10;++i)
				System.out.println("Thread is running and count is : " + i + " Thread Name : " + Thread.currentThread().getName());
			}
		
}
