package com.ramesh.project.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBClass {
	private static Connection c=null;
	public static Connection createConnection() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.jdbc.Driver");
		try
		{
		if(c==null)
		{
			c=DriverManager.getConnection("jdbc:mysql://localhost:3306/RAMESHDB","root","12345678");
		}
		}
		catch(Exception e)
		{
			System.out.println("Exception Occured");
		}
		return c;
	}
	public void terminateConnection() throws SQLException
	{
		c.close();
	}
}