package com.SqlDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
		
	private static Connection c=null;
	public static Connection creatConnection() {
		// TODO Auto-generated method stub
		/*
		 * Register the Driver
		 * Class.forName("Fully Qualified Driver Class Name"); for SQL - com.mysql.jdbc.Driver
		 * Create Connection using get Connection method of DriverManager Class
		 * Connection c=DriverManager.getConnection("Connection URL for corresponding database");
		 * getConnection() of DriverManager class returns the instance of the class which implemented connection interface
		 * Connection URL for mysql 
		 * jdbc:mysql://localhost:3306/JDBCDB
		 * API:DataBase://DataBaseHostName or IP:PortNumber/DataBaseName
		 */
		try
		{
		Class.forName("com.mysql.jdbc.Driver");
		if(c==null)
		{
		 c=DriverManager.getConnection("jdbc:mysql://localhost:3306/JDBCDB","root","12345678");
		}
		else
		{
			
		}
		
		return c;
		} 
		catch (ClassNotFoundException | SQLException e)
		{
		// TODO Auto-generated catch block
		System.out.println("Class Not Found Exception");
		e.printStackTrace();
		}
		return c;
	}

	public static void closeConnetion(Connection c2) throws SQLException {
		// TODO Auto-generated method stub
		c2.close();
	}

}
