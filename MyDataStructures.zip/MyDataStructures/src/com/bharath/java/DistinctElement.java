package com.bharath.java;

public class DistinctElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			int[] arr={5,2,7,2,4,7,8,2,3};
			DistinctElement d=new DistinctElement();
			d.getDistinctElements(arr);
	}

	private void getDistinctElements(int[] arr) {
		// TODO Auto-generated method stub
		for(int i=0;i<arr.length;++i)
		{
			boolean isDup=false;
			for(int j=arr.length-1;j>i;--j)
			{
				if(arr[j]==arr[i])
				{
					isDup=true;
					break;
				}
			}
			if(!isDup)
			{
				System.out.print(arr[i] + " ");
			}
		}
	}

}
