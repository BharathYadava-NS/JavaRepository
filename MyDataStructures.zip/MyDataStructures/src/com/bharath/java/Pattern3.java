package com.bharath.java;

public class Pattern3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count=1,j=9;
		while(j>0)
		{
			int temp=count;
					j=9;
		while(temp>0)
		{
			System.out.print(j);
			--j;--j;temp--;
		}
		count++;
		System.out.println();
		}
	}

}
