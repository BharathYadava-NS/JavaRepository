package com.bharath.java;

public class InsertionSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a={4, 2, 9, 6, 23, 12, 34, 0, 1};
		InsertionSort s=new InsertionSort();
		s.sort(a);
	}

	private void sort(int[] a) {
		// TODO Auto-generated method stub
		for(int i=1;i<a.length;++i)
		{
			int temp=a[i];
			int j=i-1;
			while(j>-1 && a[j]>temp)
			{
				a[j+1]=a[j];
				--j;
			}
			a[j+1]=temp;
			insort(a);
		}
	}

	private void insort(int[] a) {
		// TODO Auto-generated method stub
		for(int j=0;j<a.length;++j)
		{
			System.out.print(a[j] + " ");
		}
		System.out.println();
	}

}
