package com.bharath.java;

public class Ramesh1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			String s=new String("Hello1 Ramesh2 Please3 Come4 to5 Bangalore6");
			int zero=(int)'0';
			int nine=(int)'9';
			int sum=0;
			s.toCharArray();
			for(int i=0;i<s.length();++i)
			{
				int num=(int)s.charAt(i);
				if(num>=zero && num<=nine)
				{
					sum=sum+(num-zero);
				}
			}
			System.out.print(sum);
	}

}
