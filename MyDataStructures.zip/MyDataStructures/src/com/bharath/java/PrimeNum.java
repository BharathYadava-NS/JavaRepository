package com.bharath.java;

public class PrimeNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PrimeNum p=new PrimeNum();
		p.getPrime(24);
	}

	private boolean getPrime(int i) {
		// TODO Auto-generated method stub
		for(int j=2;j<=i/2;++j)
		{
			if(i%j==0)
			{
				System.out.println("Not Prime");
				return true;
			}
		}
		System.out.println("Prime");
		return false;
	}

}
