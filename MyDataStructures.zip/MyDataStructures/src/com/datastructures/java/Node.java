package com.datastructures.java;

public class Node<T> {
	private T data;
	private Node<T> nextref;
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
	public Node<T> getNextref() {
		return nextref;
	}
	public void setNextref(Node<T> nextref) {
		this.nextref = nextref;
	}
	
}
