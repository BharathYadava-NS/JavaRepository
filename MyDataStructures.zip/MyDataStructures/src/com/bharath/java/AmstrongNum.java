package com.bharath.java;

public class AmstrongNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			AmstrongNum n=new AmstrongNum();
			System.out.println(n.isAmstrong(154));
	}

	private Boolean isAmstrong(int a) {
		// TODO Auto-generated method stub
		int t,prod=1,n=a,sum=0,l=String.valueOf(n).length();
		while(n>0)
		{
			prod=1;
			t=n%10;
			for(int i=0;i<l;++i)
			{
				prod*=t;
			}
			sum+=prod;
			n=n/10;
		}
		System.out.println(sum);
		if(sum==a)
			return true;
		else 
			return false;
	}
}
