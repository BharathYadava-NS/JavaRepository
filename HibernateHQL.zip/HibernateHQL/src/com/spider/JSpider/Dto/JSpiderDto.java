package com.spider.JSpider.Dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="JspiderData")
public class JSpiderDto {
		@Id
		@GenericGenerator(name="incGen",strategy="increment")
		@GeneratedValue(generator="incGen")
		@Column(name="BatchId")
		private int bactchId;
		@Column(name="Fees")
		private int fees;
		@Column(name="StudentCount")
		private int studentCount;
		@Column(name="Branch")
		private String branch;
		@Column(name="Course")
		private String course;
		@Column(name="Faculty")
		private String faculty;
		public JSpiderDto() {
			// TODO Auto-generated constructor stub
		}
		public int getBactchId() {
			return bactchId;
		}
		public void setBactchId(int bactchId) {
			this.bactchId = bactchId;
		}
		public int getFees() {
			return fees;
		}
		public void setFees(int fees) {
			this.fees = fees;
		}
		public int getStudentCount() {
			return studentCount;
		}
		public void setStudentCount(int studentCount) {
			this.studentCount = studentCount;
		}
		public String getBranch() {
			return branch;
		}
		public void setBranch(String branch) {
			this.branch = branch;
		}
		public String getCourse() {
			return course;
		}
		public void setCourse(String course) {
			this.course = course;
		}
		public String getFaculty() {
			return faculty;
		}
		public void setFaculty(String faculty) {
			this.faculty = faculty;
		}
}
