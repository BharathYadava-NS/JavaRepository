package com.datastructures.java;

public class MyLinkedList<T> {
	private Node<T> head;
	private int length;
	public void add(T data)
	{
		Node<T> temphead=head;
		//Node<T> travel=head;
		Node<T> n=new Node<T>();
		n.setData(data);
		if(temphead==null)
		{
		head=n;
		}
		else
		{
			while(temphead.getNextref()!=null)
			{
				temphead=temphead.getNextref();
			}
			temphead.setNextref(n);
		}
		System.out.println("Added Data Member : "+ n.getData());
	}
	public void disp()
	{
		Node<T> travel=head;
		while(travel!=null)
		{
			System.out.println(travel.getData());
			travel=travel.getNextref();
			length++;
		}
	}
	public void reverse()
	{
		Node<T> prev=null;
		Node<T> next=null;
		Node<T> current=head;
		if(current==null)
		{
			System.out.println("The list is null");
		}
		else if(current.getNextref()==null)
		{
			System.out.println("The list has only one element so reversing list has no effect");
		}
		else
		{
			while(current!=null)
			{
				next=current.getNextref();
				current.setNextref(prev);
				prev=current;
				current=next;
			}
			head=prev;
		}
	}
	public int getLength()
	{
		return length;
	}
	/*public void sort()
	{
		for(Node<T> j,i=head;i.getNextref()!=null;i=i.getNextref())
		{
			j=i.getNextref();
				
		}
	}*/
}
