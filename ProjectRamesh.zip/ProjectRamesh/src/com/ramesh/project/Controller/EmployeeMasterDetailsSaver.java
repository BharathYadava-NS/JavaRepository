package com.ramesh.project.Controller;
import com.ramesh.project.DTO.EmplyeeDetailsClass;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.SQLException;

import com.ramesh.project.DAO.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EmployeeMasterDetailsSaver
 */ 
//@WebServlet("/EmployeeMasterDetailsSaver") 
public class EmployeeMasterDetailsSaver extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		EmplyeeDetailsClass newEmployee=new EmplyeeDetailsClass();
		newEmployee.setEmployeeName(request.getParameter("eName"));
		//System.out.println(request.getParameter("eName"));
		newEmployee.setAddress(request.getParameter("eAddress"));
		newEmployee.setContactNumber(request.getParameter("eContactNumber"));
		newEmployee.setEmergencyContactPerson(request.getParameter("eEmergencyName"));
		newEmployee.setContactPersonNumber(request.getParameter("eEmergencyNumber"));
		newEmployee.setEmailId(request.getParameter("eEmail"));
		newEmployee.setGender(request.getParameter("gender"));
		newEmployee.setDepartment(request.getParameter("eDepartment"));
		newEmployee.setQualification(request.getParameter("eQualification"));
		//System.out.println(request.getParameter("eId"));
		newEmployee.setEmployeeId(Integer.parseInt(request.getParameter("eId")));
		newEmployee.setStatus(request.getParameter("eStatus"));
		newEmployee.setDesignation(request.getParameter("eDesignation"));
		newEmployee.setDateOfJoining(String.valueOf(request.getParameter("eDOJ")));
		newEmployee.setDateOfBirth(String.valueOf(request.getParameter("eDOB")));
		newEmployee.setOtherDetails(request.getParameter("eOtherDetails"));
		
		DBOperations d=new DBOperations();
		try {
			if(d.saveData(newEmployee))
			{
				out.println("Data Saved Successfully");
				String s="<br><br><hr><br><br><form action='/ProjectRamesh/EmployeeLedger.jsp'><input type='submit' value='Employee Ledger' style='width:200px'/></form>";
				out.println(s);
			}
			else
			{
				out.println("Problem in saving data please contact support team.");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Exception Occured");
		}
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(req, resp);
	}

}
