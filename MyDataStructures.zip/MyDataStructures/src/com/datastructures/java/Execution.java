package com.datastructures.java;

public class Execution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			MyLinkedList<Integer> i=new MyLinkedList<>();
			i.add(1);
			i.add(2);
			i.add(3);
			i.add(4);
			i.add(7);
			i.add(9);
			i.add(8);
			System.out.println("Before Revering the list");
			i.disp();
			System.out.println("Length of the list is :" + i.getLength());
			i.reverse();
			System.out.println("After Revering the list");
			i.disp();
	}

}
