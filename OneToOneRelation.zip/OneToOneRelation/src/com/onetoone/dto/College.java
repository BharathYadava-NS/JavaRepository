package com.onetoone.dto;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class College {
	@Id
	@GenericGenerator(name="College_seq",strategy="increment")
	@GeneratedValue(generator="College_seq")
	@Column(name="College_Id")
	private int collegeId;
	@Column(name="College_Name")
	private String collegeName;
	@Column(name="College_Departments")
	private String[] collegeDepartments;
	@Column(name="College_Strength")
	private int collegeStrength;
	@Column(name="College_Faculty_Count")
	private int collegeFacultyCount;
	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@PrimaryKeyJoinColumn
	private Principal collegePrincipal;
	public int getCollegeId() {
		return collegeId;
	}

	public void setCollegeId(int collegeId) {
		this.collegeId = collegeId;
	}

	public String getCollegeName() {
		return collegeName;
	}

	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}

	public String[] getCollegeDepartments() {
		return collegeDepartments;
	}

	public void setCollegeDepartments(String[] collegeDepartments) {
		this.collegeDepartments = collegeDepartments;
	}

	public int getCollegeStrength() {
		return collegeStrength;
	}

	public void setCollegeStrength(int collegeStrength) {
		this.collegeStrength = collegeStrength;
	}

	public int getCollegeFacultyCount() {
		return collegeFacultyCount;
	}

	public void setCollegeFacultyCount(int collegeFacultyCount) {
		this.collegeFacultyCount = collegeFacultyCount;
	}

	public College() {
		// TODO Auto-generated constructor stub
	}

	public Principal getCollegePrincipal() {
		return collegePrincipal;
	}

	public void setCollegePrincipal(Principal collegePrincipal) {
		this.collegePrincipal = collegePrincipal;
	}
	
	
}
