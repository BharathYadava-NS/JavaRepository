package com.bharath.java;

public class ReverseNum {
	public int reverse(int n)
	{
		int t=0,sum=0;
		while(n>0)
		{
			t=n%10;
			sum=sum*10+t;
			n=n/10;
			System.out.println(sum);
		}
		return sum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			ReverseNum n=new ReverseNum();
			System.out.println("Reversed Number : "+n.reverse(234567));
	}
}
