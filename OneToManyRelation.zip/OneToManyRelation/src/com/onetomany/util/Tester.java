package com.onetomany.util;

import java.util.ArrayList;

import com.onetomany.dao.StudentsInSection;
import com.onetomany.dto.Section;
import com.onetomany.dto.Student;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Section s1=new Section();
		s1.setSectionName("Section A");
		s1.setSectionCapacity(60);
		s1.setSectionTeacher("Teacher A");
		Student s11=new Student();
		s11.setStudentName("Student 1");
		s11.setStudentAge(23);
		s11.setStudentNumber(1234);
		s11.setStudentEmail("1234@domain.com");
		s11.setStudentSection(s1);
		Student s12=new Student();
		s12.setStudentName("Student 2");
		s12.setStudentAge(24);
		s12.setStudentNumber(1234);
		s12.setStudentEmail("1234@domain.com");
		s12.setStudentSection(s1);
		Student s13=new Student();
		s13.setStudentName("Student 3");
		s13.setStudentAge(25);
		s13.setStudentNumber(1234);
		s13.setStudentEmail("1234@domain.com");
		s13.setStudentSection(s1);
		
		ArrayList<Student> a=new ArrayList<>();
		a.add(s11);
		a.add(s12);
		a.add(s13);
		s1.setStudentList(a);
		
		StudentsInSection dao=new StudentsInSection();
		//dao.saveDetailsOfStudents(s1);
		System.out.println("Saved Successfully");
		
		dao.getDetailsOfStudents();
		System.out.println("Details Printed");
	}

}
