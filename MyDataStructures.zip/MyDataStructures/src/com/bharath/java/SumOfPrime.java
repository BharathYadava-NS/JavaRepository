package com.bharath.java;

//import java.util.Scanner;

public class SumOfPrime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			SumOfPrime o=new SumOfPrime();
			//Scanner s=new Scanner(System.in);
			int count=0,sum=0;//num=s.nextInt();
			//for(int i=1;i<num;++i)
			//{
			int i=2;
			while(count<1000)
			{
				if(o.calcPrime(i))
					{sum+=i;count++;}	
			++i;
			}
			//}
			System.out.println(sum);
	}

	private boolean calcPrime(int i) {
		// TODO Auto-generated method stub
		for(int j=2;j<=i/2;++j)
		{
			if(i%j==0)
				return false;
		}
		return true;
	}

}
