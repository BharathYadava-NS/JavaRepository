package com.datastructures.treeds;

public class BinaryTree 
{
	private Node root=null;

	public void add(int i)
	{
		// TODO Auto-generated method stub
		Node newNode=new Node(i);
		Node traverse=root;
		if(root==null)
		{
			root=newNode;
		}
		else
		{
			travel(traverse,newNode);
		}
	}

	private void travel(Node node, Node newNode) {
		// TODO Auto-generated method stub
		if(node.getLnode()==null)
		{
			node.setLnode(newNode);
			return;
		}
		if(node.getRnode()==null)
		{
			node.setRnode(newNode);
			return;
		}
		if(newNode.getData()<=node.getData())
		{
			travel(node.getLnode(),newNode);
		}
		if(newNode.getData()>node.getData())
		{
			travel(node.getRnode(),newNode);
		}
	}

	public void display() {
		// TODO Auto-generated method stub
		if(root==null)
		{
			System.out.println("Tree is Empty");
			return;
		}
		Node temp=root;
		move(temp);
	}

	private void move(Node temp) 
	{
		// TODO Auto-generated method stub
		if(temp.getLnode()==null && temp.getRnode()==null)
		{
			System.out.println(temp.getData());
			return;
		}
		if(temp.getLnode()!=null)
		{
			move(temp.getLnode());
		}
		
		if(temp.getRnode()!=null)
		{
			move(temp.getRnode());
		}
		System.out.println(temp.getData());
	}

	public void sort() {
		// TODO Auto-generated method stub
		
	}

	/*public void delete(int i) {
		// TODO Auto-generated method stub
		Node temp=root;
		find(temp,i);
	}

	private void find(Node temp, int i) {
		// TODO Auto-generated method stub
		if(temp.getData()==i)
		{
			temp.setData(getLastNode(temp).getData());
		}
		if(i<temp.getData())
		{
			find(temp.getLnode(),i);
		}
		if(i>temp.getData())
		{
			find(temp.getRnode(),i);
		}
	}

	private Node getLastNode(Node temp) {
		// TODO Auto-generated method stub
		while(temp.getLnode()!=null && temp.getRnode()!=null)
		{
			if(temp.getLnode()!=null)
			{
				temp=temp.getLnode();
			}
			if(temp.getRnode()!=null)
			{
				temp=temp.getRnode();
			}
		}
		return temp;
	}*/
}