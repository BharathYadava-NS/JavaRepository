package com.SqlDB;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class SimpleFetch{
	Connection c=null;
	public SimpleFetch() {
		// TODO Auto-generated constructor stub
		c=DBConnection.creatConnection();
	}
	public void doFetchAll() throws SQLException
	{
		//Connection c=DBConnection.creatConnection();
		Statement s=c.createStatement();
		ResultSet rs=s.executeQuery("Select * from Employee");
		while(rs.next())
		{
			System.out.println(rs.getInt(1)+"||||"+rs.getString(2)+"||||"+rs.getString(3)+"||||"+rs.getString(4)+"||||"+rs.getLong(5)+"||||"+rs.getInt(6));
		}
		//DBConnection.closeConnetion(c);	
	}

	public void deleteUserById(int i) throws SQLException {
		// TODO Auto-generated method stub
		//Connection c=DBConnection.creatConnection();
		Statement s=c.createStatement();
		int rs=s.executeUpdate("delete from Employee where id="+i+"");
		//executeUpdate method returns the number of rows affected
		System.out.println("Rows Affected  " + rs);
		//DBConnection.closeConnetion(c);
	}
	public void insertEntry(int i, String string, String string2, String string3, long j, int k) throws SQLException {
		// TODO Auto-generated method stub
		/*
		 * Prepared Statement is an interface 
		 */
		PreparedStatement p=c.prepareStatement("insert into Employee(fname,sname,email,phoneNumber,age) values(?,?,?,?,?)");
		//p.setInt(1, i);
		p.setString(1, string);
		p.setString(2, string2);
		p.setString(3, string3);
		p.setLong(4, j);
		p.setInt(5, k);
		int rs=p.executeUpdate();
		
		System.out.println("Rows Affected  " + rs);
	}
	public void getMataDataInfo() throws SQLException {
		// TODO Auto-generated method stub
		DatabaseMetaData d=c.getMetaData();
		System.out.println("Driver Name : " + d.getDriverName());
		System.out.println("Driver info : " + d.getSQLKeywords());
		Statement s=c.createStatement();
		ResultSet rs=s.executeQuery("Select * from employee");
		ResultSetMetaData rsm=rs.getMetaData();
		System.out.println("Coloumn Count : "+rsm.getColumnCount());
		System.out.println("Coloumn Name : "+rsm.getColumnName(3));
	}
}
