package com.bharath.java;

public class StrToInt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			StrToInt c=new StrToInt();
			System.out.println("String Value : 2345 - Int Value : " + c.convert("2345"));
			System.out.println("String Value : 76289 - Int Value : " + c.convert("76289"));
			System.out.println("String Value : 90087 - Int Value : " + c.convert("90087"));
	}

	private int convert(String string) {
		// TODO Auto-generated method stub
		char[] c=string.toCharArray();
		int unizero=(int)'0';
		int sum=0;
		for (char d : c) {
			int uninum=(int)d;
			sum=(sum*10)+(uninum-unizero);
		}
		return sum;
	}

}
