package com.bharath.java;

public class DecToBin {
		public void convert(int n)
		{
			String s="";
			while(n>0)
			{
				s=n%2+s;
				n=n/2;
			}
			System.out.println(s);
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			DecToBin d=new DecToBin();
			d.convert(25);
	}
}